<html>
<head>
</head>
<body>
<table align="center">
    <h1 align="center">Home specification</h1>
    <tr>
        <td>Category of homeseeker</td>
        <td><input type="checkbox">Family
            <input type="checkbox">Bechalor</td>
    </tr>
    <tr>
        <td>Number of Room</td>
        <td><input type="number"></td>
    </tr>
    <tr>
        <td>Number of Master Bedroom</td>
        <td><input type="number"></td>
    </tr>
    <tr>
        <td>Number of Dining</td>
        <td><input type="number"></td>
    </tr>
    <tr>
        <td>Number of Drawing</td>
        <td><input type="number"></td>
    </tr>
    <tr>
        <td>Number of Attached Bathroom</td>
        <td><input type="number"></td>
    </tr>

    <tr>
        <td>Number of Common Bathroom</td>
        <td><input type="number"></td>
    </tr>

    <tr>
        <td>Number of Balcony</td>
        <td><input type="number"></td>
    </tr>

    <tr>
        <td>Floor Number</td>
        <td><input type="number"></td>
    </tr>

    <tr>
        <td>Lift</td>
        <td><input type="radio">Available
            <input type="radio">Not Available</td>
    </tr>

    <tr>
        <td>Block </td>
        <td><input type="text"></td>
    </tr>

    <tr>
        <td>Road </td>
        <td><input type="text"></td>
    </tr>

    <tr>
        <td>Rent </td>
        <td><input type="text"></td>
    </tr>
   

    <tr>
        <td>photo 1 </td>
        <td><input type="file"></td>
    </tr>

    <tr>
        <td>photo 2 </td>
        <td><input type="file"></td>
    </tr>

    <tr>
        <td>photo 3</td>
        <td><input type="file"></td>
    </tr>

    <tr>
        <td>photo 4</td>
        <td><input type="file"></td>
    </tr> 
    <tr>
        <td><a href="owner.html">Back</a></td>
        <td><input type="submit" value="Post"></td>
    </tr>
</table>    

</body>
</html>