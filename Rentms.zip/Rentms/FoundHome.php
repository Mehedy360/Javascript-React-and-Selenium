<html>
<head>
</head>
<body>
    <div align ="center">
    <input type="submit" value="FOUND HOME">
    <input type="submit" value="NOT FOUND YET">
    <p>***After selecting found Home you will be removed from all the places you applied for rent***</p>
    <a href = "homeseeker.html">Back</a>
    <div>
</body>

</html>