<html>
    <head>
    </head>
    <body>
        <div align ="center">
            <h2>Applied List Of homeseeker</h2>
            <table border="1px" >
                <tr>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Rent</th>
                    <th>Phone</th>
                    <th>Action</th>

                </tr>
                <tr>
                    <td>Abdul</td>
                    <td>10/02/2021</td>
                    <td>200000</td>
                    <td>01198113113</td>
                    <td><a href="ConfirmHomeSeeker.php">Confirm</a></td>
                    <td><a href="DeleteHomeSeeker.php">Delete</a></td>
                </tr>
                <tr>
                    <td>Karim</td>
                    <td>17/05/2021</td>
                    <td>150000</td>
                    <td>01198113113</td>
                    <td><a href="ConfirmHomeSeeker.php">Confirm</a></td>
                    <td><a href="DeleteHomeSeeker.php">Delete</a></td>
                </tr>
                <tr>
                    <td>Moklesh</td>
                    <td>16/03/2021</td>
                    <td>140000</td>
                    <td>01415113113</td>
                    <td><a href="ConfirmHomeSeeker.php">Confirm</a></td>
                    <td><a href="DeleteHomeSeeker.php">Delete</a></td>
                </tr>
                <tr>
                    <td>Kamlesh</td>
                    <td>11/02/2021</td>
                    <td>170000</td>
                    <td>01488113113</td>
                    <td><a href="ConfirmHomeSeeker.php">Confirm</a></td>
                    <td><a href="DeleteHomeSeeker.php">Delete</a></td>
                </tr>
</table>
                
                
                <a href = "owner.html">Back</a>
                
            
        </div>
    </body>
</html>