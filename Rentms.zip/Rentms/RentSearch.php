<html>
    <head>
    </head>
    <body>
        <div align = "center">
            <h1>Search For Rent</h1>
        <label>Location</label>&nbsp;<label> Boshundhora</label> &nbsp; <label>Block</label><input type="text"> &nbsp;<label>Road</label> <input type="text">
        <table border="1">
            <tr>
                <th>Rooms</th>
                <th>Master Bedroom</th>
                <th>Dining</th>
                <th>Drawing</th>
                <th>Attached Bathroom</th>
                <th>Common Bathroom</th>
                <th>Balcony</th>
                <th>Floor</th>
                <th>Lift</th>
                <th>Road</th>
                <th>Block</th>
                <th>Rent</th>
                <th>Action</th>
            </tr>

            <tr>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>2</td>
                <td>15</td>
                <td>G</td>
                <td>20000</td>
                <td><a href="">Confirm</a></td>
               
            </tr>
            <tr>
                <td>5</td>
                <td>2</td>
                <td>3</td>
                <td>4</td>
                <td>2</td>
                <td>1</td>
                <td>1</td>
                <td>2</td>
                <td>1</td>
                <td>10</td>
                <td>B</td>
                <td>30000</td>
                <td><a href="">Confirm</a></td>
            
            </tr>
            <tr>
                <td>7</td>
                <td>5</td>
                <td>4</td>
                <td>3</td>
                <td>2</td>
                <td>1</td>
                <td>3</td>
                <td>2</td>
                <td>2</td>
                <td>18</td>
                <td>H</td>
                <td>40000</td>
                <td><a href="">Confirm</a></td>
     
            </tr>
        </table>
        <a href = "homeseeker.html">Back</a>
        </div>
    </body>
</html>